Hey there, it's Spritz.

Here is where I will be listing some information on how to use the executor..

RAIN:
Lvl: 7

--

HOW TO ADD MORE SCRIPTS TO THE EXECUTOR:

Go to the "Scripts" folder, make a text document, inside, set the script, it will most likely run.

--

( WEBSITE AND DISCORD BY BRYDEN CODES AND SPRITZ INC. )